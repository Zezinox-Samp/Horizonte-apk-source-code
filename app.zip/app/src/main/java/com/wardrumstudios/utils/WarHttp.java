package com.wardrumstudios.utils;

public class WarHttp {
    protected WarHttp(WarBase warBase)
    {
        System.out.println("**** WarHttp::Init");
    }

    public String HttpGet(String str)
    {
        System.out.println("**** HttpGet");
        return "";
    }
}
