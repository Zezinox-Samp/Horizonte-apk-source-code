package com.horizonte.game.samp.ui.buttons;

import android.app.Activity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.nvidia.devtech.NvEventQueueActivity;
import com.horizonte.game.R;
import com.horizonte.game.samp.util.view.Utils;


public class ButtonPanel {
    ConstraintLayout panel_layout;
    Activity aactivity;
    ConstraintLayout bAlt;
    ConstraintLayout bBind;
    ConstraintLayout bFirst;
    TextView bFirstText;
    ConstraintLayout f249bG;
    ConstraintLayout f251bN;
    ConstraintLayout f254bY;
    ConstraintLayout f254bH;
    ConstraintLayout f254bC;
    Animation animScale;
    Animation buttonShow;
    Animation buttonHide;
    boolean mEnable;

    public ButtonPanel(Activity activity) {
        aactivity = activity;
        panel_layout = activity.findViewById(R.id.buttonpanel);

        bFirst = aactivity.findViewById(R.id.button_first);
        bFirstText = aactivity.findViewById(R.id.button_first_text);
        f249bG = aactivity.findViewById(R.id.button_G);
        bAlt = aactivity.findViewById(R.id.button_ALT);
        bBind = aactivity.findViewById(R.id.button_BIND);
        f254bY = aactivity.findViewById(R.id.button_Y);
        f254bH = aactivity.findViewById(R.id.button_H);
        f254bC = aactivity.findViewById(R.id.button_C);
        f251bN = aactivity.findViewById(R.id.button_N);
        bFirst.setVisibility(View.GONE);
        f249bG.setVisibility(View.GONE);
        bAlt.setVisibility(View.GONE);
        bBind.setVisibility(View.GONE);
        f254bY.setVisibility(View.GONE);
        f254bH.setVisibility(View.GONE);
        f254bC.setVisibility(View.GONE);
        f251bN.setVisibility(View.GONE);
        panel_layout.setVisibility(View.GONE);

        setListeners();

        mEnable = true;
        animScale = AnimationUtils.loadAnimation(aactivity, R.anim.scale2);
        buttonShow = AnimationUtils.loadAnimation(aactivity, R.anim.button_show);
        buttonHide = AnimationUtils.loadAnimation(aactivity, R.anim.button_hide);

        Utils.HideLayout(panel_layout, false);
    }

    void setVisibleWithAnim(ConstraintLayout constraintLayout, int i) {
        if (constraintLayout.getVisibility() != i) {
            constraintLayout.startAnimation(i == 0 ? buttonShow : buttonHide);
            constraintLayout.setVisibility(i);
        }
    }

    void setListeners() {
        bFirst.setOnClickListener(view -> {
            mEnable = !mEnable;
            view.startAnimation(ButtonPanel.this.animScale);

            if (mEnable) {
                bFirstText.setText(">>");
                setVisibleWithAnim(bBind, View.GONE);
                setVisibleWithAnim(f254bY, View.GONE);
                setVisibleWithAnim(f251bN, View.GONE);
                setVisibleWithAnim(f254bH, View.GONE);
                setVisibleWithAnim(f254bC, View.GONE);
            } else {
                bFirstText.setText("<<");
                setVisibleWithAnim(bBind, View.VISIBLE);
                setVisibleWithAnim(f254bY, View.VISIBLE);
                setVisibleWithAnim(f251bN, View.VISIBLE);
                setVisibleWithAnim(f254bH, View.VISIBLE);
                setVisibleWithAnim(f254bC, View.VISIBLE);
            }
        });

        f249bG.setOnClickListener(view -> {
            view.startAnimation(ButtonPanel.this.animScale);
            NvEventQueueActivity.getInstance().onClickButton(1);
        });

        bAlt.setOnClickListener(view -> {
            view.startAnimation(ButtonPanel.this.animScale);
            NvEventQueueActivity.getInstance().onClickButton(2);
        });

        bBind.setOnClickListener(view -> {
            view.startAnimation(ButtonPanel.this.animScale);
            NvEventQueueActivity.getInstance().onClickButton(3);
        });

        f254bY.setOnClickListener(view -> {
            view.startAnimation(ButtonPanel.this.animScale);
            NvEventQueueActivity.getInstance().onClickButton(4);
        });

        f251bN.setOnClickListener(view -> {
            view.startAnimation(ButtonPanel.this.animScale);
            NvEventQueueActivity.getInstance().onClickButton(5);
        });

        f254bH.setOnClickListener(view -> {
            view.startAnimation(ButtonPanel.this.animScale);
            NvEventQueueActivity.getInstance().onClickButton(6);
        });

        f254bC.setOnClickListener(view -> {
            view.startAnimation(ButtonPanel.this.animScale);
            NvEventQueueActivity.getInstance().onClickButton(7);
        });
    }

    public void show() {
            Utils.ShowLayout(panel_layout, true);
            setVisibleWithAnim(bFirst, 0);
            setVisibleWithAnim(f249bG, 0);
            setVisibleWithAnim(bAlt, 0);
            bBind.setVisibility(View.GONE);
            f254bY.setVisibility(View.GONE);
            f254bH.setVisibility(View.GONE);
            f254bC.setVisibility(View.GONE);
            f251bN.setVisibility(View.GONE);

            bFirstText.setText(">>");
    }
    public void hide(){
        Utils.HideLayout(panel_layout, true);
    }
}
