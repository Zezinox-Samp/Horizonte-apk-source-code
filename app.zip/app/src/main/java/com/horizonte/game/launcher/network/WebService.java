package com.horizonte.game.launcher.network;

import com.horizonte.game.launcher.settings.Settings;
import com.horizonte.game.launcher.network.api.Api;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class WebService {
    private static WebService instance;
    private Retrofit retrofit = new Retrofit.Builder().baseUrl(Settings.API_LINK).addConverterFactory(GsonConverterFactory.create()).build();
    private WebService() { }

    public static WebService getInstance() {
        if (instance == null) {
            instance = new WebService();
        }
        return instance;
    }

    public Api getApiService() { return this.retrofit.create(Api.class); }
}
