package com.horizonte.game.samp.util.view;

public class Range {
    private int end = -1;
    private int start = -1;

    Range() {
    }

    public int getStart() {
        return this.start;
    }

    public void setStart(int start2) {
        this.start = start2;
    }

    public int getEnd() {
        return this.end;
    }

    public void setEnd(int end2) {
        this.end = end2;
    }
}
