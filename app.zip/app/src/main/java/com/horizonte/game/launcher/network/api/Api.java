package com.horizonte.game.launcher.network.api;

import com.horizonte.game.launcher.network.models.Links;
import com.horizonte.game.launcher.network.models.Server;
import com.horizonte.game.launcher.network.models.Story;

import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.http.GET;

public interface Api {

    @GET("mobile/api.json")
    Call<Links> getLinks();

    @GET("mobile/servers.json")
    Call<ArrayList<Server>> getServers();

    @GET("mobile/stories.json")
    Call<ArrayList<Story>> getStories();
}
