package com.horizonte.game.samp.util.view;

import android.view.KeyEvent;
import android.widget.TextView;
public final /* synthetic */ class $$Lambda$MaskedEditText$uX_YztYUHcbq6dV_J1fDsTb0DjM implements TextView.OnEditorActionListener {
    public static final /* synthetic */ $$Lambda$MaskedEditText$uX_YztYUHcbq6dV_J1fDsTb0DjM INSTANCE = new $$Lambda$MaskedEditText$uX_YztYUHcbq6dV_J1fDsTb0DjM();

    private /* synthetic */ $$Lambda$MaskedEditText$uX_YztYUHcbq6dV_J1fDsTb0DjM() {
    }

    public final boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
        return MaskedEditText.lambda$new$0(textView, i, keyEvent);
    }
}
