package com.horizonte.game.launcher.adapters;

import static com.horizonte.game.launcher.settings.Settings.GAME_PATH;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.horizonte.game.R;
import com.horizonte.game.launcher.fragments.ConnectFragment;
import com.horizonte.game.launcher.fragments.HomeFragment;
import com.horizonte.game.launcher.network.models.Server;
import com.horizonte.game.launcher.network.sampquery.SampQuery;
import com.horizonte.game.launcher.others.App;
import com.horizonte.game.launcher.others.Utils;
import com.horizonte.game.launcher.service.DownloadService;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;

import org.ini4j.Wini;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;

public class ServerAdapter extends RecyclerView.Adapter<ServerAdapter.ViewHolder> {
    public HomeFragment monitoringFragment;
    private ArrayList<Server> serverList;

    public ServerAdapter(HomeFragment monitoringFragment2, ArrayList<Server> arrayList) {
        this.monitoringFragment = monitoringFragment2;
        this.serverList = arrayList;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_server, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        new Thread(() -> {
            InetAddress ServerAddress = null;
            SampQuery query;
            try {
                ServerAddress = InetAddress.getByName(serverList.get(i).getIP());
            } catch (UnknownHostException e) {
                Utils.writeLog(monitoringFragment.getContext(), 'e', "Erro de servidor: " + e.getMessage());
            }
            if(ServerAddress != null) {
                if (ServerAddress.getHostAddress() != null || !ServerAddress.getHostAddress().isEmpty()) {
                    query = new SampQuery(ServerAddress.getHostAddress(), serverList.get(i).getPort());
                    if (query.connect()) {
                        String[] serverInfo = query.getInfo();
                        int currentPlayerCount = Integer.parseInt(serverInfo[1]); // Extrair o número de jogadores
                        int maxPlayerCount = Integer.parseInt(serverInfo[2]); // Extrair o número máximo de jogadores

                        new Handler(Looper.getMainLooper()).post(() -> {
                            viewHolder.online.setText(serverInfo[1] + "/" + serverInfo[2]);

                            float progress = (float) currentPlayerCount / maxPlayerCount * 100;
                            viewHolder.circularProgressBar.setProgress(progress);
                        });


                        query.close();
                    } else {
                        new Handler(Looper.getMainLooper()).post(() -> {
                            viewHolder.online.setText("Não disponível");
                        });
                    }
                } else {
                    new Handler(Looper.getMainLooper()).post(() -> {
                        viewHolder.online.setText("Não disponível");
                    });
                }
            } else {
                new Handler(Looper.getMainLooper()).post(() -> {
                    viewHolder.online.setText("Não disponível");
                });
            }
        }).start();

        viewHolder.serverName.setText(serverList.get(i).getName());
        viewHolder.serverID.setText("0"+serverList.get(i).getID());

        viewHolder.btnPlay.setOnClickListener(view -> {
            view.startAnimation(AnimationUtils.loadAnimation(monitoringFragment.getContext(), R.anim.button_click));
            if(!Utils.isGameInstalled()) { return; }
            File gameFiles = new File(GAME_PATH + "data/ver.ini");
            Integer TARGET_GAMEFILES_VERSION = 0;
            if (gameFiles.exists()) {
                try {
                    Wini w = new Wini(gameFiles);
                    TARGET_GAMEFILES_VERSION = Integer.valueOf(w.get("versions", "gameFilesVersion"));
                    w.store();
                } catch (IOException e) {
                    Utils.writeLog(monitoringFragment.getContext(), 'e', e.getMessage());
                }
            }

            if (App.getInstance().targetGameFilesVersion != TARGET_GAMEFILES_VERSION) {
                App.getInstance().downloadID = App.INSTALL_TYPE_UPDATE_GAMEFILES;
                monitoringFragment.getContext().startActivity(new Intent(monitoringFragment.getContext(), DownloadService.class));
                monitoringFragment.getActivity().finish();
                return;
            }

            File settings = new File(GAME_PATH + "SAMP/settings.ini");
            if(settings.exists()) {
                Wini w = null;
                try {
                    w = new Wini(settings);

                    // seleção do servidor (o cliente lê a configuração e se conecta a um servidor específico)
                    w.put("client", "server", serverList.get(i).getID());
                    w.store();
                } catch (IOException e) {
                    Utils.writeLog(monitoringFragment.getContext(), 'e', "Erro: "+e.getMessage());
                }
                FragmentManager fragmentManager = monitoringFragment.getActivity().getSupportFragmentManager();
                ConnectFragment ConnectFragment = new ConnectFragment();

                FragmentTransaction transaction = fragmentManager.beginTransaction();
                transaction.replace(R.id.fragment_place, ConnectFragment);
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });
    }

    public int getItemCount() { return this.serverList.size(); }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView serverName;
        public TextView online;
        public TextView serverID;
        public ConstraintLayout btnPlay;

        CircularProgressBar circularProgressBar;

        public ViewHolder(View view) {
            super(view);
            this.serverID = (TextView) view.findViewById(R.id.textView11);
            this.serverName = (TextView) view.findViewById(R.id.textView12);
            this.online = (TextView) view.findViewById(R.id.textView14);
            this.btnPlay = (ConstraintLayout) view.findViewById(R.id.view_online);
            this.circularProgressBar = (CircularProgressBar) view.findViewById(R.id.imageView9); // Substitua pelo ID correto do seu CircularProgressBar
        }
    }
}
