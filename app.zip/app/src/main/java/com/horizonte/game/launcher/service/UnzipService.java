package com.horizonte.game.launcher.service;

import static com.horizonte.game.launcher.settings.Settings.GAME_PATH;
import static com.horizonte.game.launcher.settings.Settings.PATH_DOWNLOADS;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.PowerManager;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.horizonte.game.R;
import com.horizonte.game.launcher.activities.MainActivity;
import com.horizonte.game.launcher.others.Utils;
import com.horizonte.game.launcher.settings.Preferences;
import com.hzy.libp7zip.P7ZipApi;

import org.ini4j.Wini;

import java.io.File;
import java.io.IOException;

import es.dmoral.toasty.Toasty;

public class UnzipService extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unzip);
        startUnzipping();
    }

    private void startUnzipping() {
        int position = getIntent().getIntExtra("position", 0);
        String zipName = getZipName(position);

        UnzipTask unzipTask = new UnzipTask(this, zipName);
        unzipTask.execute(PATH_DOWNLOADS, GAME_PATH, zipName + ".zip");
    }

    private String getZipName(int position) {
        switch (position) {
            case 1:
                return "client";
            case 2:
                return "game";
            case 3:
                return "files_upd";
            default:
                throw new IllegalArgumentException("Invalid position: " + position);
        }
    }

    private class UnzipTask extends AsyncTask<String, Integer, String> {

        private Context context;
        private String zipName;
        private PowerManager.WakeLock mWakeLock;

        public UnzipTask(Context context, String zipName) {
            this.context = context;
            this.zipName = zipName;
        }

        @Override
        protected String doInBackground(String... params) {
            String filePath = params[0];
            String destinationPath = params[1];
            String fileName = params[2];
            P7ZipApi.executeCommand(UnZip.getExtractCmd(filePath + fileName, destinationPath));
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Utils.setDownloading(true);
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getClass().getName());
            mWakeLock.acquire();
        }

        @Override
        protected void onProgressUpdate(Integer... progress) {
            super.onProgressUpdate(progress);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            //ao decompatar
            mWakeLock.release();
            clearDownloadsPath();
            Utils.setDownloading(false);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancelAll();
            if (result != null) {
                Toasty.error(UnzipService.this, "Erro ao descompactar: " + result, Toast.LENGTH_SHORT).show();
            } else {
                File settings = new File(GAME_PATH+"SAMP/settings.ini");
                if(settings.exists()) {
                    try {
                        Wini w = new Wini(settings);
                        w.put("client", "nickname", Preferences.getString(UnzipService.this, Preferences.NICKNAME));
                        w.store();
                    } catch (IOException e) {
                        Utils.writeLog(UnzipService.this, 'e', "Erro: "+e.getMessage());
                    }
                }
                Toasty.success(UnzipService.this, "O jogo foi instalado com sucesso!", Toast.LENGTH_SHORT).show();
            }
            Intent intent = new Intent(UnzipService.this, MainActivity.class);
            intent.putExtras(getIntent());
            startActivity(intent);
            finish();
        }
    }

    //Deletar arquivos baixados ao finalizar todos.
    private void clearDownloadsPath()
    {
        File download_path = new File(PATH_DOWNLOADS);
        if (!download_path.exists()) {
            download_path.mkdirs();
        } else {
            File client = new File(PATH_DOWNLOADS, "client.apk");
            if(client.exists()) client.delete();
            File launcher = new File(PATH_DOWNLOADS, "launcher.apk");
            if(launcher.exists()) launcher.delete();
            File gameFiles = new File(PATH_DOWNLOADS, "game.zip");
            if(gameFiles.exists()) gameFiles.delete();
            File filesUpd = new File(PATH_DOWNLOADS, "files_upd.zip");
            if(filesUpd.exists()) filesUpd.delete();
            File filesGraph = new File(PATH_DOWNLOADS, "files_graph.zip");
            if(filesGraph.exists()) filesGraph.delete();
        }
    }
}
