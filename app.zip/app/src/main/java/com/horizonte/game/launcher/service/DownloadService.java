package com.horizonte.game.launcher.service;

import static com.horizonte.game.launcher.settings.Settings.PATH_DOWNLOADS;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.NotificationManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StatFs;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.horizonte.game.BuildConfig;
import com.horizonte.game.R;
import com.horizonte.game.launcher.others.App;
import com.horizonte.game.launcher.others.Utils;
import com.liulishuo.filedownloader.BaseDownloadTask;
import com.liulishuo.filedownloader.FileDownloadSampleListener;
import com.liulishuo.filedownloader.FileDownloader;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;

import java.io.File;

import es.dmoral.toasty.Toasty;

public class DownloadService extends AppCompatActivity {
    private TextView speedText, timeLeft, infoBytes, downloadPercent;
    private CircularProgressBar downloadProgress;
    private Handler handler;
    public int downloadId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        handler = new Handler();
        setContentView(R.layout.activity_load);
        downloadProgress = findViewById(R.id.imageView9);
        speedText = findViewById(R.id.textView35);
        infoBytes = findViewById(R.id.textView33);
        timeLeft = findViewById(R.id.textView37);
        downloadPercent = findViewById(R.id.textView31);

        long freeMemory = getFreeMemory();
        if (freeMemory < 2000) {
            handler.postDelayed(() -> {
                Dialog dialog = new Dialog(this);
                dialog.setContentView(R.layout.item_dialog_settings);
                dialog.setCancelable(false);
                dialog.getWindow().setBackgroundDrawableResource(R.drawable.background_dialog_full);
                dialog.getWindow().setLayout(-1, -2);
                ((TextView) dialog.findViewById(R.id.message)).setText("Você tem pouca memória restante, a instalação não é possível.");
                ((TextView) dialog.findViewById(R.id.ok)).setOnClickListener(view1 -> {
                    view1.startAnimation(AnimationUtils.loadAnimation(this, R.anim.button_click));
                    handler.postDelayed(() -> dialog.dismiss(), 200);
                });
                dialog.show();
            }, 200);
            Utils.writeLog(this, 'i', "Pouca memória");
            return;
        }
        //
        if(App.getInstance().downloadID == null) {
            Utils.writeLog(this, 'e', "Erro: downloadID é nulo.");
            return;
        }
        startDownload(App.getInstance().downloadID);
    }

    private long getFreeMemory() {
        try {
            StatFs statFs = new StatFs(Environment.getExternalStorageDirectory().getAbsolutePath());
            return (statFs.getAvailableBlocksLong() * statFs.getBlockSizeLong()) / 1048576;
        } catch (Exception unused) {
            return 268435455;
        }
    }

    private void startDownload(final int id)
    {
        try {
            clearDownloadsPath();
            downloadId = createDownloadTask(id).start();
        } catch (Exception e) {
            Utils.writeLog(DownloadService.this, 'e', "Erro startDownload: " + e.getMessage());
        }
    }

    private BaseDownloadTask createDownloadTask(final int position)
    {
        String url = "";
        boolean isDir = false;
        String path = "null";

        switch (position) {
            case 1:
                url = App.getInstance().URL_CLIENT;
                path = PATH_DOWNLOADS + "client.apk";
                break;
            case 2:
                // Seleciona a versão do jogo dependendo do resultado da versão da GPU do jogador
                switch(App.GPUName) {
                    case "Adreno":
                        url = App.getInstance().URL_GAME_ADRENO;
                        path = PATH_DOWNLOADS + "game.zip";
                    break;

                    case "Mali":
                        url = App.getInstance().URL_GAME_MALI;
                        path = PATH_DOWNLOADS + "game.zip";
                    break;

                    case "PowerVR":
                        url = App.getInstance().URL_GAME_POWERVR;
                        path = PATH_DOWNLOADS + "game.zip";
                    break;
                }
                break;

            case 3:
                url = App.getInstance().URL_GAME_FILES_UPDATE;
                path = PATH_DOWNLOADS + "files_upd.zip";
                break;

            default:
                throw new IllegalStateException("Valor inesperado: " + position);
        }

        return FileDownloader.getImpl().create(url).
                setPath(path, false).
                setCallbackProgressTimes(300).
                setMinIntervalUpdateSpeed(400).
                setListener(new FileDownloadSampleListener() {
                    @Override
                    protected void pending(BaseDownloadTask task, int soFarBytes, int totalBytes) {
                        super.pending(task, soFarBytes, totalBytes);
                    }
                    @SuppressLint("SetTextI18n")
                    @Override
                    protected void progress(BaseDownloadTask task, int soFarBytes, int totalBytes) {
                        super.progress(task, soFarBytes, totalBytes);
                        final float percent = soFarBytes / (float) totalBytes;

                        downloadProgress.setProgressMax(100);
                        downloadProgress.setProgress((int) (percent * 100));
                        speedText.setText(Utils.formatFileSize(task.getSpeed() * 1024L));
                        infoBytes.setText(Utils.formatFileSize(soFarBytes) + "/" + Utils.formatFileSize(totalBytes));

                        // Calcula o tempo restante em segundos
                        long remainingBytes = totalBytes - soFarBytes;
                        float downloadSpeedKBps = task.getSpeed(); // Velocidade em KBps
                        float downloadSpeedBps = downloadSpeedKBps * 1024; // Velocidade em Bps
                        float timeRemainingSeconds = remainingBytes / downloadSpeedBps;

                        // Converte o tempo restante para minutos e segundos
                        int minutes = (int) (timeRemainingSeconds / 60);
                        int seconds = (int) (timeRemainingSeconds % 60);
                        timeLeft.setText(minutes + ":" + seconds);
                        downloadPercent.setText((int) (percent * 100)+"%");

                        if(position == 1) {
                            downloadPercent.setText((int) (percent * 100)+"%");
                        }
                        if(position == 3) {
                            downloadPercent.setText((int) (percent * 100)+"%");
                        }
                        if(position == 4) {
                            downloadPercent.setText((int) (percent * 100)+"%");
                        }
                    }
                    @Override
                    protected void error(BaseDownloadTask task, Throwable e) {
                        super.error(task, e);
                        Utils.writeLog(DownloadService.this, 'e', "Erro FileDownloader: " + e);
                        Toasty.error(DownloadService.this, "Erro: "+e, Toast.LENGTH_LONG).show();
                    }
                    @Override
                    protected void connected(BaseDownloadTask task, String etag, boolean isContinue, int soFarBytes, int totalBytes) {
                        super.connected(task, etag, isContinue, soFarBytes, totalBytes);
                        Utils.setDownloading(true);
                    }
                    @Override
                    protected void paused(BaseDownloadTask task, int soFarBytes, int totalBytes) {
                        super.paused(task, soFarBytes, totalBytes);
                        Utils.setDownloading(false);
                    }
                    @Override
                    protected void completed(BaseDownloadTask task) {
                        super.completed(task);
                        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancelAll();
                        if(position == 1) {
                            Toasty.info(DownloadService.this, "Confirmar Instalação").show();
                            Utils.setDownloading(false);
                            installAPK("client");
                        }
                        else if(position == 2) {
                            Intent intent = new Intent(DownloadService.this, UnzipService.class);
                            intent.putExtra("position", 2);
                            startActivity(intent);
                            finish();
                        }
                        else if (position == 3) {
                            Intent intent = new Intent(DownloadService.this, UnzipService.class);
                            intent.putExtra("position", 3);
                            startActivity(intent);
                            finish();
                        }
                        else if (position == 4) {
                            Intent intent = new Intent(DownloadService.this, UnzipService.class);
                            intent.putExtra("position", 4);
                            startActivity(intent);
                            finish();
                        }
                        //Utils.setDownloading(false);
                    }
                    @Override
                    protected void warn(BaseDownloadTask task) { super.warn(task); }
                });
    }

    private void installAPK(String apkname) {
        try {
            File file = new File(PATH_DOWNLOADS, apkname + ".apk");
            Intent intent;
            if (file.exists()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    Uri apkUri = FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".provider", file);
                    intent = new Intent(Intent.ACTION_INSTALL_PACKAGE);
                    intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.setData(apkUri);
                } else {
                    Uri apkUri = Uri.fromFile(file);
                    intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                }
                startActivity(intent);
            }
        } catch (Exception e) {
            Utils.writeLog(this, 'e', "Erro de instalação:" + e.getMessage());
        }
    }

    //Deletar arquivos baixados ao finalizar todos.
    private void clearDownloadsPath()
    {
        File download_path = new File(PATH_DOWNLOADS);
        if (!download_path.exists()) {
            download_path.mkdirs();
        } else {
            File client = new File(PATH_DOWNLOADS, "client.apk");
            if(client.exists()) client.delete();
            File launcher = new File(PATH_DOWNLOADS, "launcher.apk");
            if(launcher.exists()) launcher.delete();
            File gameFiles = new File(PATH_DOWNLOADS, "game.zip");
            if(gameFiles.exists()) gameFiles.delete();
            File filesUpd = new File(PATH_DOWNLOADS, "files_upd.zip");
            if(filesUpd.exists()) filesUpd.delete();
            File filesGraph = new File(PATH_DOWNLOADS, "files_graph.zip");
            if(filesGraph.exists()) filesGraph.delete();
        }
    }
}
