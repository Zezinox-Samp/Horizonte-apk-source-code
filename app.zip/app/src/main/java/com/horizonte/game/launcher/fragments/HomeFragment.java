package com.horizonte.game.launcher.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.horizonte.game.launcher.others.App;
import com.horizonte.game.R;
import com.horizonte.game.launcher.adapters.ServerAdapter;
import com.horizonte.game.launcher.network.models.Server;
import com.horizonte.game.launcher.network.api.ServerListener;

import java.util.ArrayList;

public class HomeFragment extends Fragment {

	private RecyclerView serversRecycler;
	private ArrayList<Server> serverList;
	private ServerAdapter serverAdapter;
	private ServerListener serverListener;
	private LinearLayout help_btn;
	public HomeFragment() {}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view;
		view = inflater.inflate(R.layout.fragment_home, container, false);

		Animation animation = AnimationUtils.loadAnimation(getContext(), R.anim.button_click);

		help_btn = (LinearLayout) view.findViewById(R.id.help_btn);

		serverList = new ArrayList<>();
		serversRecycler = view.findViewById(R.id.rvServers); // server
		serversRecycler.setLayoutManager(new LinearLayoutManager(getActivity()));
		serverAdapter = new ServerAdapter(HomeFragment.this, App.getInstance().getServerList());
		serversRecycler.setAdapter(serverAdapter);
		serverListener = () -> serverAdapter.notifyDataSetChanged();
		return view;
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
	}
}