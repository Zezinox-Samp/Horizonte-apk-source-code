package com.horizonte.game.launcher.activities;

import static es.dmoral.toasty.Toasty.LENGTH_SHORT;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.horizonte.game.R;
import com.horizonte.game.launcher.others.App;
import com.horizonte.game.launcher.settings.Preferences;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import es.dmoral.toasty.Toasty;

public class GPUActivity extends AppCompatActivity implements GLSurfaceView.Renderer {
    private static final int GL_RENDERER = 7937;
    private GLSurfaceView glSurfaceView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gpu);

        TextView textView = findViewById(R.id.textLoadingApp);
        textView.setText(getString(R.string.detecting_gpu));

        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        activityManager.getDeviceConfigurationInfo();
        glSurfaceView = new GLSurfaceView(this);
        glSurfaceView.setRenderer(this);
        ((ViewGroup) textView.getParent()).addView(glSurfaceView);

        new CountDownTimer(3000L, 9999L) {
            @Override
            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
                Toasty.success(GPUActivity.this, "GPU: " + App.GPUName + " detectada com sucesso!", LENGTH_SHORT).show();

                // Continue
                Intent intent = new Intent(GPUActivity.this, MainActivity.class);
                if (Preferences.getString(App.getInstance(), Preferences.NICKNAME).isEmpty()) {
                    intent = new Intent(GPUActivity.this, StartActivity.class);
                }
                intent.putExtras(getIntent());
                startActivity(intent);
                finish();
            }
        }.start();
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        final String gpuInfo = gl.glGetString(GL_RENDERER).toLowerCase();

        runOnUiThread(() -> {
            if (gpuInfo.contains("adreno")) {
                App.GPUName = "Adreno";
            } else if (gpuInfo.contains("mali")) {
                App.GPUName = "Mali";
            } else if (gpuInfo.contains("power")) {
                App.GPUName = "PowerVR";
            }
            glSurfaceView.setVisibility(View.GONE);
        });
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
    }

    @Override
    public void onDrawFrame(GL10 gl) {
    }
}
