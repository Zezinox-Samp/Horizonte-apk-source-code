package com.horizonte.game.launcher.others;

import android.app.*;
import android.net.ConnectivityManager;

import androidx.multidex.MultiDexApplication;

import java.io.File;
import java.util.ArrayList;

import es.dmoral.toasty.Toasty;
import com.horizonte.game.launcher.network.models.Server;
import com.horizonte.game.launcher.network.api.ServerListener;
import com.horizonte.game.launcher.network.models.Story;
import com.horizonte.game.launcher.settings.Settings;


public class App extends MultiDexApplication
{
	private static App instance;
	public Integer downloadID = null;
	public static final Integer INSTALL_TYPE_CLIENT = 1;
	public static final Integer INSTALL_TYPE_GAMEFILES = 2;
	public static final Integer INSTALL_TYPE_UPDATE_GAMEFILES = 3;
	private String tempNick;
	private String currentGPU;
	// Detect GPU
	public static String GPUName;
	//SERVERS
	public ArrayList<Server> serverList;
	public ServerListener serverListener;
	//STORIES
	public ArrayList<Story> stories;
	//API
	public String URL_CLIENT;
	public String URL_GAME_POWERVR;
	public String URL_GAME_MALI;
	public String URL_GAME_ADRENO;
	public String URL_GAME_DEFAULT;
	public String URL_GAME_FILES_UPDATE;
	public String URL_SITE;
	public String URL_INSTAGRAM;
	public String URL_DISCORD;
	public String URL_YOUTUBE;
	public String URL_SHOP;
	public Integer targetClientVersion;
	public Integer targetGameFilesVersion;
	//LINKS UI
	public String URL_LOADSCREEN;
	//Developer
	public String URL_DEVELOPER;
	
	@Override
	public void onCreate() {
		super.onCreate();
		instance = this;
		serverList = new ArrayList<>();
		stories = new ArrayList<>();

		initLogger();

		if (!Utils.isGameInstalled()) {
			downloadID = INSTALL_TYPE_GAMEFILES;
		}
	}
	private void initLogger () {
		try {
			File appDir = new File(Settings.APP_PATH);
			if (!appDir.exists()) {
				appDir.mkdirs();
			}
			File logcat = new File(Settings.APP_PATH+ "logcat.txt");
			if (logcat.exists()) {
				logcat.delete();
			}
			logcat.createNewFile();
			Runtime runtime = Runtime.getRuntime();
			runtime.exec("logcat -f " + logcat.getAbsolutePath());
		} catch (Exception e) {
			Utils.writeLog(getInstance(), 'e', "Erro: InitLogger" +e.getMessage());
		}
		try {
			((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).setNetworkPreference(ConnectivityManager.DEFAULT_NETWORK_PREFERENCE);
		}
		catch (Exception unused) {}
	}

	public static App getInstance() { return instance; } // obter contexto do aplicativo
	public String getTempNickName() { return this.tempNick; } // nickname temporário
	public void setTempNickName(String str) { this.tempNick = str; }
	public ArrayList<Server> getServerList() { return this.serverList; } // Lista de servidores
	public ArrayList<Story> getStories() { return this.stories; } // lista de stories
	public void setGPU(String str) { currentGPU = str; }
	public String getGPU() { return currentGPU;}

	public static boolean isExternalStorageAvailable(Activity activity) {
		try {
			activity.getExternalFilesDir((String) null).getAbsolutePath();
			return true;
		} catch (Exception unused) {
			Toasty.error(activity, "Sem acesso ao armazenamento!", Toasty.LENGTH_LONG);
			return false;
		}
	}
	public static boolean isAppInstalledFromMarket(String marketNamePacket) {
		if(getInstance().getPackageManager().
				getInstallerPackageName(getInstance().getPackageName()).equals(marketNamePacket)) {
			return true;
		}
		return false;
	}
}