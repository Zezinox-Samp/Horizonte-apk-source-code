package com.horizonte.game.launcher.others;

import static com.horizonte.game.launcher.settings.Settings.APP_PATH;
import static com.horizonte.game.launcher.settings.Settings.GAME_PATH;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;

import es.dmoral.toasty.Toasty;

public class Utils extends AppCompatActivity {

    protected void onCreate(Bundle bundle) { super.onCreate(bundle); }

    static boolean downloading = false;
    static Integer typeInstall = 0;
    public static Integer INSTALL_TYPE_CLIENT = 1;
    public static Integer INSTALL_TYPE_REINSTALL = 2;
    public static Integer INSTALL_TYPE_UPDATE_GAMEFILES = 3;
    public static Integer INSTALL_TYPE_GRAPHICS = 4;

    // 1 - reinstall the game (only files)
    // 2 - graph (gta_sa.set)

    public static boolean getDownloading() { return downloading; }
    public static Integer getInstallType () { return typeInstall; }
    public static boolean setDownloading(boolean value) { return downloading = value; }
    public static Integer setInstallType(int type) { return typeInstall = type; }

    public static void writeLog(Activity activity, char type, String message) {
        File logFile = new File(activity.getExternalFilesDir((String) null).getPath() + "/logs_launcher.txt");
        try {
            Date dateNow = new Date();
            SimpleDateFormat formatForDateNow = new SimpleDateFormat("dd.MM.yyyy hh:mm:ss", Locale.ENGLISH);
            if (logFile.exists()) {
                Writer output = new BufferedWriter(new FileWriter(logFile, true));
                if (type == 'e') {
                    Log.e("LOG", message);
                    output.write("\nERRO: ");
                } else if (type == 'i') {
                    Log.i("LOG", message);
                    output.write("\nINFO: ");
                } else if (type == 'w') {
                    Log.w("LOG", message);
                    output.write("\nAVISO: ");
                }
                output.write(formatForDateNow.format(dateNow) + " - " + message);
                output.flush();
                output.close();
            } else if (logFile.createNewFile()) {
                Writer output2 = new BufferedWriter(new FileWriter(logFile, false));
                if (type == 'e') {
                    output2.write("ERRO: ");
                } else if (type == 'i') {
                    output2.write("INFO: ");
                } else if (type == 'w') {
                    output2.write("AVISO: ");
                }
                output2.write(formatForDateNow.format(dateNow) + " - " + message);
                output2.flush();
                output2.close();
            }
        } catch (IOException e) {
            Log.e("LOG", e.toString());
        }
    }
    public static void writeLog(Context context, char type, String message) {
        File logFile = new File(context.getExternalFilesDir((String) null).getPath() + "/logs_launcher.txt");
        try {
            Date dateNow = new Date();
            SimpleDateFormat formatForDateNow = new SimpleDateFormat("dd.MM.yyyy hh:mm:ss", Locale.ENGLISH);
            if (logFile.exists()) {
                Writer output = new BufferedWriter(new FileWriter(logFile, true));
                if (type == 'e') {
                    output.write("\nERRO: ");
                } else if (type == 'i') {
                    output.write("\nINFO: ");
                } else if (type == 'w') {
                    output.write("\nAVISO: ");
                }
                output.write(formatForDateNow.format(dateNow) + " - " + message);
                output.flush();
                output.close();
            } else if (logFile.createNewFile()) {
                Writer output2 = new BufferedWriter(new FileWriter(logFile, false));
                if (type == 'e') {
                    output2.write("ERRO: ");
                } else if (type == 'i') {
                    output2.write("INFO: ");
                } else if (type == 'w') {
                    output2.write("AVISO: ");
                }
                output2.write(formatForDateNow.format(dateNow) + " - " + message);
                output2.flush();
                output2.close();
            }
        } catch (IOException e) {
            Log.e("LOG", e.toString());
        }
    }
    public static String convertStreamToString(InputStream is) {
        Scanner s = new Scanner(is).useDelimiter("\\A");
        return s.hasNext() ? s.next().replace(",", ",\n") : "";
    }
    public static String formatFileSize(long size) {
        String hrSize;

        double kiloByte = size / 1024.0;
        double megaByte = kiloByte / 1024.0;
        double gigaByte = megaByte / 1024.0;
        double teraByte = gigaByte / 1024.0;

        DecimalFormat dec = new DecimalFormat("0.00");

        if (teraByte > 1) {
            hrSize = dec.format(teraByte).concat(" TB");
        } else if (gigaByte > 1) {
            hrSize = dec.format(gigaByte).concat(" GB");
        } else if (megaByte > 1) {
            hrSize = dec.format(megaByte).concat(" MB");
        } else if (kiloByte > 1) {
            hrSize = dec.format(kiloByte).concat(" KB");
        } else {
            hrSize = dec.format(size).concat(" Bytes");
        }
        return hrSize;
    }
    public static void showMessage(String _s, Context context) {
        Toasty.info(context, _s, Toast.LENGTH_LONG).show(); }

    public static boolean isInternetConnected(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }

    public static boolean isGameInstalled() {
        String gamePath = GAME_PATH;
        File[] requiredDirectories = {
                new File(gamePath, "anim"),
                new File(gamePath, "audio"),
                new File(gamePath, "data"),
                new File(gamePath, "models"),
                new File(gamePath, "texdb"),
        };
        File sampSettingsFile = new File(gamePath, "SAMP/settings.ini");

        for (File directory : requiredDirectories) {
            if (!directory.exists()) {
                return false;
            }
        }

        return sampSettingsFile.exists();
    }



    public static void writeLog(Exception e)
    {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        String text = sw.toString();
        writeFile(APP_PATH+"/logs_launcher.txt", text);
    }

    public static void writeFile(String path, String str)
    {
        File file = new File(path);
        try { if (!file.exists()) file.createNewFile(); } catch (IOException e) { e.printStackTrace(); }
        FileWriter fileWriter = null;
        try {
            fileWriter = new FileWriter(new File(path), false);
            fileWriter.write(str);
            fileWriter.flush();
        } catch (IOException e) { e.printStackTrace(); } finally { try { if (fileWriter != null) fileWriter.close(); } catch (IOException e) { e.printStackTrace(); }}
    }
}
