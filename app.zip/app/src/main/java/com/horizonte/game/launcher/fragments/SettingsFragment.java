package com.horizonte.game.launcher.fragments;

import static com.horizonte.game.launcher.settings.Settings.GAME_PATH;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.horizonte.game.launcher.others.App;
import com.horizonte.game.R;
import com.horizonte.game.launcher.others.Utils;
import com.horizonte.game.launcher.settings.Preferences;
import com.horizonte.game.launcher.activities.MainActivity;

import org.ini4j.Wini;

import java.io.File;
import java.io.IOException;

import es.dmoral.toasty.Toasty;

public class SettingsFragment extends Fragment
{
	private EditText nickName;
	private Button repairGame, btnVK, btnYT, btnDiscord;
	private ToggleButton btnNotifications, btnFpsCounter, btnKeyboardGoogle, btnVoice;
	private TextView whoDeveloped;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view;
		view = inflater.inflate(R.layout.fragment_settings, container, false);
		nickName = view.findViewById(R.id.editTextTextNickName);
		//repairGame = view.findViewById(R.id.repairGame);
		btnNotifications = view.findViewById(R.id.switch1);
		btnFpsCounter = view.findViewById(R.id.switch2);
		btnKeyboardGoogle = view.findViewById(R.id.switch3);
		btnVoice = view.findViewById(R.id.switch4);
		btnVK = view.findViewById(R.id.button_vk);
		btnYT = view.findViewById(R.id.button_yt);
		btnDiscord = view.findViewById(R.id.button_discord);
		whoDeveloped = view.findViewById(R.id.textView18);

		// Entrada de nickname
		nickName.setText(Preferences.getString(getActivity(), Preferences.NICKNAME));
		nickName.setOnEditorActionListener((v, actionId, event) -> {
			if (actionId == EditorInfo.IME_ACTION_SEARCH ||
					actionId == EditorInfo.IME_ACTION_DONE ||
					event.getAction() == KeyEvent.ACTION_DOWN &&
							event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
				String obj = nickName.getText().toString();
				if (obj.isEmpty()) {
					Toasty.warning(getActivity(), getResources().getString(R.string.enterNik), Toast.LENGTH_LONG).show();
				} else if (obj.length() < 3) {
					Toasty.warning(getActivity(), getResources().getString(R.string.minLengthNik), Toast.LENGTH_LONG).show();
				} else {
					Preferences.putString(getActivity(), Preferences.NICKNAME, obj);
					Toasty.success(getActivity(), "Seu nickname foi salvo: "+obj).show();
					File settings = new File(GAME_PATH+"SAMP/settings.ini");
					if(settings.exists()) {
						try {
							Wini w = new Wini(settings);
							w.put("client", "nickname", obj);
							w.store();
						} catch (IOException e) {
							Utils.writeLog(getActivity(), 'e', "Erro: "+e.getMessage());
						}
					} else {
						Utils.writeLog(getActivity(), 'e', "Nenhum arquivo settings.ini encontrado");
					}
				}
			}
			return false;
		});

		// botão para corrigir o jogo (reinstalar)
		/*repairGame.setOnClickListener(view1 -> {
			delete(new File(GAME_PATH));
			App.getInstance().downloadID = App.INSTALL_TYPE_GAMEFILES;
			Intent intent = new Intent(getActivity(), DownloadService.class);
			intent.putExtras(getActivity().getIntent());
			startActivity(intent);
			getActivity().finish();
		});*/

		// notificações e contador de fps
		btnNotifications.setChecked(Preferences.getBoolean(getActivity(), Preferences.NOTIFICATION, true));
		btnNotifications.setOnCheckedChangeListener((compoundButton, b) -> Preferences.putBoolean(getActivity(), Preferences.NOTIFICATION, b));
		btnFpsCounter.setChecked(false);
		btnKeyboardGoogle.setChecked(false);
		btnVoice.setChecked(false);

		File f = new File(GAME_PATH+"SAMP/settings.ini");
		if(f.exists()) {
			Wini w = null;
			try {
				w = new Wini(f);
				Boolean fps = new Boolean(w.get("launcher", "displayfps"));
				if(fps == true) {
					btnFpsCounter.setChecked(true);
				}

				Boolean keyboardGoogle = new Boolean(w.get("launcher", "keyboard"));
				if(keyboardGoogle == true) {
					btnKeyboardGoogle.setChecked(true);
				}

				Boolean voice = new Boolean(w.get("voice", "Enable"));
				if(voice == true) {
					btnVoice.setChecked(true);
				}

				w.store();
			} catch (IOException e) {
				Utils.writeLog(getActivity(), 'e', "Erro: "+e.getMessage());
			}
		}

		btnFpsCounter.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
				Wini w = null;
				try {
					w = new Wini(f);
					if(b) {
						w.put("launcher", "displayfps", true);
					} else w.put("launcher", "displayfps", false);
					w.store();
				} catch (IOException e) {
					Utils.writeLog(getActivity(), 'e', "Erro: "+e.getMessage());
				}
			}
		});

		btnKeyboardGoogle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
				Wini w = null;
				try {
					w = new Wini(f);
					if(b) {
						w.put("launcher", "keyboard", true);
					} else w.put("launcher", "keyboard", false);
					w.store();
				} catch (IOException e) {
					Utils.writeLog(getActivity(), 'e', "Erro: "+e.getMessage());
				}
			}
		});

		btnVoice.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
				Wini w = null;
				try {
					w = new Wini(f);
					if(b) {
						w.put("voice", "Enable", true);
					} else w.put("voice", "Enable", false);
					w.store();
				} catch (IOException e) {
					Utils.writeLog(getActivity(), 'e', "Erro: "+e.getMessage());
				}
			}
		});

		// quem desenvolveu
		whoDeveloped.setOnClickListener(view15 -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(App.getInstance().URL_DEVELOPER))));
		whoDeveloped.setText(Html.fromHtml("<font color=\"#FFFFFF\"> Developed by unk.cs </font><font color=\"#FFFFFF\"><a href=\"\"></a></font><font color=\"#FFFFFF\"></font>"), TextView.BufferType.SPANNABLE);

		// botões de mídia social
		btnVK.setOnClickListener(view14 -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(App.getInstance().URL_INSTAGRAM))));
		btnYT.setOnClickListener(view13 -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(App.getInstance().URL_YOUTUBE))));
		btnDiscord.setOnClickListener(view12 -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(App.getInstance().URL_DISCORD))));
		return view;
	}
	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
	}

	private void delete(File file) {
		if (file.exists()) {
			if (file.isDirectory()) {
				for (File delete : file.listFiles()) {
					delete(delete);
				}
				file.delete();
				return;
			}
			file.delete();
		}
	}

	private void loadFragment(Fragment fragment) {
		FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
		transaction.replace(R.id.fragment_place, fragment);
		transaction.addToBackStack(null);
		transaction.commit();
	}
}
