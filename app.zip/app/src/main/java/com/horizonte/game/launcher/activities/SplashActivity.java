package com.horizonte.game.launcher.activities;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import com.google.firebase.messaging.FirebaseMessaging;
import com.horizonte.game.launcher.others.App;
import com.horizonte.game.BuildConfig;
import com.horizonte.game.R;
import com.horizonte.game.launcher.others.Utils;
import com.horizonte.game.launcher.settings.Preferences;
import com.horizonte.game.launcher.fragments.UpdateFragment;
import com.horizonte.game.launcher.network.WebService;
import com.horizonte.game.launcher.network.models.Links;
import com.horizonte.game.launcher.network.models.Server;
import com.horizonte.game.launcher.network.models.Story;
import com.liulishuo.filedownloader.FileDownloader;

import java.util.ArrayList;
import java.util.List;

import es.dmoral.toasty.Toasty;
import pub.devrel.easypermissions.EasyPermissions;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SplashActivity extends AppCompatActivity implements EasyPermissions.PermissionCallbacks {
    // permissions
    private static final int MAIN_PERMISSIONS_REQUEST_CODE = 300;
    private Handler handler;
    String[] main_permissions = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.RECORD_AUDIO
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        handler = new Handler();
        if (EasyPermissions.hasPermissions(this, main_permissions)) {
            Utils.writeLog(this, 'i', "Aplicativo iniciado com sucesso!");
            Init();
        } else {
            Utils.writeLog(this, 'i', "Aplicativo não tem permissões necessárias!");
            EasyPermissions.requestPermissions(this,
                    "O aplicativo precisa de permissão para gravar na memória",
                    MAIN_PERMISSIONS_REQUEST_CODE, main_permissions);
        }
    }
    private void Init()
    {
        FileDownloader.setup(this);
        if (!Preferences.getBoolean(this, Preferences.FIRST_START)) {
            FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                if (!task.isSuccessful()) {
                    Utils.writeLog(SplashActivity.this, 'e', "FCM Reg failed: "+task.getException());
                    return;
                }
                Preferences.putString(App.getInstance(), Preferences.USER_FCM_KEY, task.getResult());
                Utils.writeLog(SplashActivity.this, 'i', "FCM reg success! Token: "+task.getResult());
            });
            Preferences.putBoolean(SplashActivity.this, Preferences.FIRST_START, true);
            loadAPI();
        }
        else {
            loadAPI();
        }
    }

    // carregando api, notícias, servidores, etc.
    private void loadAPI() {
        WebService.getInstance().getApiService().getLinks().enqueue(new Callback<Links>() {
            public void onResponse(Call<Links> call, Response<Links> response) {
                if(response.isSuccessful())
                {
                    if(response.body() != null) {
                        
                        // versões
                        App.getInstance().targetClientVersion = response.body().getTargetClientVersion();
                        App.getInstance().targetGameFilesVersion = response.body().getTargetGameFilesVersion();
                        
                        // links para arquivos
                        App.getInstance().URL_CLIENT = response.body().getUrlClient();
                        App.getInstance().URL_GAME_POWERVR = response.body().getUrlFilesPowerVR();
                        App.getInstance().URL_GAME_MALI = response.body().getUrlFilesMali();
                        App.getInstance().URL_GAME_ADRENO = response.body().getUrlFilesAdreno();
                        App.getInstance().URL_GAME_DEFAULT = response.body().getUrlFilesDefault();
                        App.getInstance().URL_GAME_FILES_UPDATE = response.body().getUrlFilesUpdate();
                        
                        // Shop
                        App.getInstance().URL_SHOP = response.body().getUrlShop();
                        
                        // rede sociais
                        App.getInstance().URL_SITE = response.body().getUrlSite();
                        App.getInstance().URL_INSTAGRAM = response.body().getUrlInstagram();
                        App.getInstance().URL_DISCORD = response.body().getUrlDiscord();
                        App.getInstance().URL_YOUTUBE = response.body().getUrlYoutube();

                        //links do desenvolvedor do launcher
                        App.getInstance().URL_DEVELOPER = response.body().getUrlDeveloper();
                        
                        // links para ui/samp
                        App.getInstance().URL_LOADSCREEN = response.body().getUrlLoadScreen();
                        
                        // carregando o servidores
                        loadServers();
                    }
                } else {
                    Toasty.error(SplashActivity.this, "Não é possível conectar ao servidores do Horizonte Roleplay. Por favor, tente mais tarde!", Toasty.LENGTH_LONG).show();
                    Utils.writeLog(SplashActivity.this, 'e', "Erro ao carregar lista API: "+response.errorBody());
                }
            }
            public void onFailure(Call<Links> call, Throwable th) {
                Utils.writeLog(SplashActivity.this, 'e', "Erro ao carregar lista API: "+th.getMessage());
                if(!Utils.isInternetConnected(SplashActivity.this))
                {
                    Toasty.error(SplashActivity.this, "Você não tem uma conexão com a Internet.", Toasty.LENGTH_LONG).show();
                    return;
                }
                Toasty.error(SplashActivity.this, "Erro de conexão dos servidores do Horizonte Roleplay. O servidor não está disponível.", Toasty.LENGTH_LONG).show();
            }
        });
    }

    private void loadServers() {
        WebService.getInstance().getApiService().getServers().enqueue(new Callback<ArrayList<Server>>() {
            public void onResponse(Call<ArrayList<Server>> call, Response<ArrayList<Server>> response) {
                if(response.isSuccessful())
                {
                    if (response.body() != null) {
                        App.getInstance().serverList.clear();
                        App.getInstance().serverList.addAll(response.body());
                        if (App.getInstance().serverListener != null) {
                            App.getInstance().serverListener.onChange();
                        }
                        loadStories();
                    }
                } else {
                    Utils.writeLog(SplashActivity.this, 'e', "Erro ao carregar a lista de servidores: "+response.errorBody());
                }
            }
            public void onFailure(Call<ArrayList<Server>> call, Throwable th) {
                Utils.writeLog(SplashActivity.this, 'e', "Erro ao carregar a lista de servidores: "+th.getMessage());
                if(!Utils.isInternetConnected(SplashActivity.this))
                {
                    Toasty.error(SplashActivity.this, "Você não tem uma conexão com a Internet.", Toasty.LENGTH_LONG).show();
                    return;
                }
                Toasty.error(SplashActivity.this, "Erro de conexão do servidor. O servidor não está disponível.", Toasty.LENGTH_LONG).show();
            }
        });
    }

    private void loadStories() { // carregamento dos stories
        WebService.getInstance().getApiService().getStories().enqueue(new Callback<ArrayList<Story>>() {
            public void onResponse(Call<ArrayList<Story>> call, Response<ArrayList<Story>> response) {
                if(response.isSuccessful()) {
                    if (response.body() != null) {
                        App.getInstance().stories.clear();
                        App.getInstance().stories.addAll(response.body());
                        runOnUiThread(() -> startLauncher());
                    }
                } else {
                    Utils.writeLog(SplashActivity.this, 'e', "Erro ao carregar a lista de notícias: "+response.errorBody());
                }
            }
            public void onFailure(Call<ArrayList<Story>> call, Throwable th) {
                Utils.writeLog(SplashActivity.this, 'e', "Erro ao carregar a lista de notícias: "+th.getMessage());
                if(!Utils.isInternetConnected(SplashActivity.this))
                {
                    Toasty.error(SplashActivity.this, "Você não tem uma conexão com a Internet.", Toasty.LENGTH_LONG).show();
                    return;
                }
                Toasty.error(SplashActivity.this, "Erro de conexão do servidor. O servidor não está disponível.", Toasty.LENGTH_LONG).show();
            }
        });
    }

    //-------------------------------------------------------------------

    private void startLauncher() {
        if(App.getInstance().targetClientVersion != BuildConfig.VERSION_CODE) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.fragmentContainer, new UpdateFragment());
            transaction.commit();
            return;
        }
        handler.postDelayed((Runnable) () -> {
            Intent intent = new Intent(this, MainActivity.class);
            if(Preferences.getString(App.getInstance(), Preferences.NICKNAME).isEmpty())
            {
                intent = new Intent(this, GPUActivity.class);
            }
            intent.putExtras(getIntent());
            startActivity(intent);
            finish();
        }, 1000);
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }
    public void onPermissionsGranted(int requestCode, List<String> list) {
        if(requestCode == MAIN_PERMISSIONS_REQUEST_CODE) {
            Init();
        }
    }
    public void onPermissionsDenied(int requestCode, List<String> list) {
        if(requestCode == MAIN_PERMISSIONS_REQUEST_CODE) {
            Utils.writeLog(SplashActivity.this, 'i', "Erro de problemas de Permissão");
            Toasty.error(SplashActivity.this, "O aplicativo precisa ter todas as permissões solicitadas!!!", Toast.LENGTH_LONG).show();
            //finish();
        }
    }
}