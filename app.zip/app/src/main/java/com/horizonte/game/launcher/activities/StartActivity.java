package com.horizonte.game.launcher.activities;
import static com.horizonte.game.launcher.settings.Settings.GAME_PATH;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import es.dmoral.toasty.Toasty;
import com.horizonte.game.launcher.others.App;
import com.horizonte.game.R;
import com.horizonte.game.launcher.others.Utils;
import com.horizonte.game.launcher.settings.Preferences;
import com.horizonte.game.launcher.service.DownloadService;

import org.ini4j.Wini;

import java.io.File;
import java.io.IOException;

public class StartActivity extends AppCompatActivity
{
    Button download;
    EditText nickName;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_start);
        download = findViewById(R.id.button);
        nickName = findViewById(R.id.editTextTextPersonName);

        // Salvar nickname botão enter do teclado
        nickName.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                    actionId == EditorInfo.IME_ACTION_DONE ||
                    event.getAction() == KeyEvent.ACTION_DOWN &&
                            event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
                String obj = nickName.getText().toString();
                if (obj.isEmpty()) {
                    Toasty.warning(this, getResources().getString(R.string.enterNik), Toast.LENGTH_LONG).show();
                } else if (obj.length() < 3) {
                    Toasty.warning(this, getResources().getString(R.string.minLengthNik), Toast.LENGTH_LONG).show();
                } else {
                    Preferences.putString(this, Preferences.NICKNAME, obj);
                    Toasty.success(this, "Seu nickname foi salvo: "+obj).show();
                    if(!Utils.isGameInstalled()) {
                        App.getInstance().downloadID = App.INSTALL_TYPE_GAMEFILES;
                        startActivity(new Intent(StartActivity.this, DownloadService.class));
                        finish();
                    } else {
                        File settings = new File(GAME_PATH+"SAMP/settings.ini");
                        if(settings.exists()) {
                            try {
                                Wini w = new Wini(settings);
                                w.put("client", "nickname", Preferences.getString(StartActivity.this, Preferences.NICKNAME));
                                w.store();
                            } catch (IOException e) {
                                Utils.writeLog(StartActivity.this, 'e', "Erro: "+e.getMessage());
                            }
                        }

                        Intent intent = new Intent(StartActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }
            }
            return false;
        });
        // botão "continuar"
        download.setOnClickListener(view -> {
            String obj = nickName.getText().toString();
            if (obj.isEmpty()) {
                Toasty.warning(StartActivity.this, getResources().getString(R.string.enterNik), Toast.LENGTH_LONG).show();
            } else if (obj.length() < 4) {
                Toasty.warning(StartActivity.this, getResources().getString(R.string.minLengthNik), Toast.LENGTH_LONG).show();
            } else {
                Preferences.putString(StartActivity.this, Preferences.NICKNAME, obj);
                Toasty.success(StartActivity.this, "Seu nickname foi salvo: "+obj).show();
                if(!Utils.isGameInstalled()) {
                    App.getInstance().downloadID = App.INSTALL_TYPE_GAMEFILES;
                    startActivity(new Intent(StartActivity.this, DownloadService.class));
                    finish();
                } else {
                    File settings = new File(GAME_PATH+"SAMP/settings.ini");
                    if(settings.exists()) {
                        try {
                            Wini w = new Wini(settings);
                            w.put("client", "nickname", Preferences.getString(StartActivity.this, Preferences.NICKNAME));
                            w.store();
                        } catch (IOException e) {
                            Utils.writeLog(StartActivity.this, 'e', "Erro: "+e.getMessage());
                        }
                    }

                    Intent intent = new Intent(StartActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}
