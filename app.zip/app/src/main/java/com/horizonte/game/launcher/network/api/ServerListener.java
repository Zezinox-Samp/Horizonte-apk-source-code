package com.horizonte.game.launcher.network.api;

public interface ServerListener {
    void onChange();
}
