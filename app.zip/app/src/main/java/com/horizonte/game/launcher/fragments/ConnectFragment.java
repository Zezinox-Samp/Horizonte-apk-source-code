package com.horizonte.game.launcher.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.content.Intent;

import com.horizonte.game.R;
import com.horizonte.game.samp.GTASA;

public class ConnectFragment extends Fragment {
    private static final long COOLDOWN_DURATION = 5000;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_connect, container, false);
        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
        new Handler().postDelayed(() -> {
            Intent intent = new Intent(getContext(), GTASA.class);
            startActivity(intent);
            getActivity().finish();
        }, COOLDOWN_DURATION);
    }
}
