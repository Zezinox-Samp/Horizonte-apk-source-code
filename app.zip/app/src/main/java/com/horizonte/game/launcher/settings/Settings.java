package com.horizonte.game.launcher.settings;

public class Settings {
    public static final String APP_PATH = "/storage/emulated/0/Android/data/com.horizonte.game/";
    public static final String PATH_DOWNLOADS = APP_PATH+ "cache/";
    public static final String GAME_PATH = APP_PATH+ "files/";
    
    public static final String API_LINK = "https://horizonte-rp.com/";
}

