package com.horizonte.game.launcher.network.models;
import com.google.gson.annotations.SerializedName;
import com.horizonte.game.BuildConfig;

public class Links {
    // Links Client
    @SerializedName("URL_CLIENT")
    private String URL_CLIENT;
    @SerializedName("URL_GAME_POWERVR")
    private String URL_GAME_POWERVR;
    @SerializedName("URL_GAME_MALI")
    private String URL_GAME_MALI;
    @SerializedName("URL_GAME_ADRENO")
    private String URL_GAME_ADRENO;
    @SerializedName("URL_GAME_DEFAULT")
    private String URL_GAME_DEFAULT;
    @SerializedName("URL_GAME_FILES_UPD")
    private String URL_GAME_FILES_UPDATE;

    // Links Social Media
    @SerializedName("URL_SITE")
    private String URL_SITE;
    @SerializedName("URL_INSTAGRAM")
    private String URL_INSTAGRAM;
    @SerializedName("URL_DISCORD")
    private String URL_DISCORD;
    @SerializedName("URL_YOUTUBE")
    private String URL_YOUTUBE;
    @SerializedName("URL_SHOP")
    private String URL_SHOP;

    // Links Update
    @SerializedName("clientVersionCode")
    private Integer targetClientVersion = BuildConfig.VERSION_CODE;
    @SerializedName("gameFilesVersionCode")
    private Integer targetGameFilesVersion;

    // Links UI
    @SerializedName("URL_LOADSCREEN")
    private String URL_LOADSCREEN;

    // Links developer launcher
    @SerializedName("URL_DEVELOPER")
    private String URL_DEVELOPER;

    public Links() { }
    public final Integer getTargetClientVersion() { return targetClientVersion; }
    public final Integer getTargetGameFilesVersion() { return targetGameFilesVersion; }
    public final String getUrlClient() { return URL_CLIENT; }
    public final String getUrlFilesPowerVR() { return URL_GAME_POWERVR; }
    public final String getUrlFilesMali() { return URL_GAME_MALI; }
    public final String getUrlFilesAdreno() { return URL_GAME_ADRENO; }
    public final String getUrlFilesDefault() { return URL_GAME_DEFAULT; }
    public final String getUrlFilesUpdate() { return URL_GAME_FILES_UPDATE; }
    public final String getUrlShop() { return URL_SHOP;}
    public final String getUrlSite() { return URL_SITE; }
    public final String getUrlInstagram() { return URL_INSTAGRAM; }
    public final String getUrlDiscord() { return URL_DISCORD; }
    public final String getUrlYoutube() {return URL_YOUTUBE;}
    public final String getUrlLoadScreen() {return URL_LOADSCREEN;}
    public final String getUrlDeveloper() {return URL_DEVELOPER;}

}
