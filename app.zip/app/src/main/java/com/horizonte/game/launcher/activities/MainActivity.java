package com.horizonte.game.launcher.activities;

import static com.horizonte.game.launcher.settings.Settings.PATH_DOWNLOADS;
import static es.dmoral.toasty.Toasty.LENGTH_SHORT;

import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.gauravk.bubblenavigation.BubbleNavigationLinearView;
import com.gauravk.bubblenavigation.listener.BubbleNavigationChangeListener;

import com.horizonte.game.R;
import com.horizonte.game.launcher.fragments.HomeFragment;
import com.horizonte.game.launcher.fragments.SettingsFragment;
import com.horizonte.game.launcher.fragments.StoriesFragment;
import com.horizonte.game.launcher.others.App;
import com.horizonte.game.launcher.others.Utils;
import com.horizonte.game.launcher.service.DownloadService;
import com.liulishuo.filedownloader.FileDownloader;

import java.io.File;

import es.dmoral.toasty.Toasty;

public class MainActivity extends AppCompatActivity
{
    Fragment selectedFragment = null;
    private boolean doubleBackToExitPressedOnce;
    Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        handler = new Handler();

        if(!Utils.isGameInstalled())
        {
            App.getInstance().downloadID = App.INSTALL_TYPE_GAMEFILES;
            Intent intent = new Intent(MainActivity.this, DownloadService.class);
            intent.putExtras(getIntent());
            startActivity(intent);
            finish();
            return;
        }

        setContentView(R.layout.activity_main);

        BubbleNavigationLinearView bubbleNavigation = findViewById(R.id.bubbleNavigation);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_place,
                new HomeFragment()).commit();

        bubbleNavigation.setNavigationChangeListener(new BubbleNavigationChangeListener() {
            @Override
            public void onNavigationChanged(View view, int position) {
                switch (position) {
                    case 0:
                        selectedFragment = new StoriesFragment();
                        break;
                    case 1:
                        selectedFragment = new HomeFragment();
                        break;
                    case 2:
                        selectedFragment = new SettingsFragment();
                        break;
                }
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_place,
                        selectedFragment).commit();
            }
        });

        // criando um diretório de download
        File download_path = new File(PATH_DOWNLOADS);
        if(!download_path.exists()) { download_path.mkdirs(); }
    }

    // sair do segundo pressionamento do botão Voltar
    @Override
    public void onBackPressed()
    {
        if (doubleBackToExitPressedOnce) {
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancelAll();
            FileDownloader.getImpl().pauseAll();
            System.exit(0);
            return;
        }
        Toasty.info(MainActivity.this, "Clique novamente para sair", LENGTH_SHORT).show();
        doubleBackToExitPressedOnce = true;
        handler.postDelayed(() -> doubleBackToExitPressedOnce = false, 2000);
    }

    private void loadFragmentWithAnimation(Fragment fragment, int enterAnim, int exitAnim) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(enterAnim, exitAnim, enterAnim, exitAnim);
        transaction.replace(R.id.fragment_place, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}
