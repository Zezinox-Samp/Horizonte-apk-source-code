package com.horizonte.game.launcher.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.horizonte.game.launcher.others.App;
import com.horizonte.game.R;
import com.horizonte.game.launcher.activities.MainActivity;
import com.horizonte.game.launcher.adapters.NewsAdapter;

public class StoriesFragment extends Fragment {
    public StoriesFragment() {}

    private RecyclerView newsRv;
    private NewsAdapter newsAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view;
        view = inflater.inflate(R.layout.fragment_stories, container, false);
        newsRv = view.findViewById(R.id.rvNews);
        newsRv.setLayoutManager(new LinearLayoutManager(getActivity()));
        newsAdapter = new NewsAdapter(getActivity());
        newsRv.setAdapter(newsAdapter);
        newsAdapter.addItems(App.getInstance().getStories());
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }
}
