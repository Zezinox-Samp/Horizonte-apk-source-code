package com.horizonte.game.samp.ui.loadingscreen;

import android.app.Activity;
import android.net.Uri;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.google.android.exoplayer2.Player;
import com.horizonte.game.R;
import com.horizonte.game.launcher.others.App;
import com.horizonte.game.samp.util.view.Utils;

//NEW
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;

public class LoadScreen {
    private static final int MAX_PERCENTAGE = 100;
    
    FrameLayout serverLayout;
    TextView percentText;
    Activity aactivity;

    //TEST
    private SimpleExoPlayer player;
    private PlayerView playerView;

    public LoadScreen(Activity activity){
        aactivity = activity;
        serverLayout = activity.findViewById(R.id.loadScreen_layout);
        percentText = activity.findViewById(R.id.text_loadingScreen);
        playerView = activity.findViewById(R.id.player_view);

        player = ExoPlayerFactory.newSimpleInstance(aactivity, new DefaultTrackSelector());
        playerView.setPlayer(player);

        Uri videoUri = Uri.parse(App.getInstance().URL_LOADSCREEN);
        MediaSource mediaSource = new ProgressiveMediaSource.Factory(new DefaultDataSourceFactory(aactivity, Util.getUserAgent(aactivity, "agent-horizonte")))
                .createMediaSource(videoUri);

        player.prepare(mediaSource);
        player.setRepeatMode(Player.REPEAT_MODE_ALL);

        Utils.HideLayout(serverLayout, false);
    }

    public void Update(int percent) {
        String text = (percent <= MAX_PERCENTAGE) ? String.format("Carregando o jogo (%d%%)", percent) : "Iniciando o jogo...";
        percentText.setText(text);
    }

    public void Show() {
        player.setPlayWhenReady(true);
        Utils.ShowLayout(serverLayout, false);

    }

    public void Hide() {
        player.setPlayWhenReady(false);
        player.release();

        Utils.HideLayout(serverLayout, false);
        Utils.HideLayout(playerView, false);
    }
}